module.exports = {
    mongoService: require('./mongo.service')
}