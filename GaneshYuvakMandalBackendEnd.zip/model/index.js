module.exports = {
    responseModel: require('./response')
}