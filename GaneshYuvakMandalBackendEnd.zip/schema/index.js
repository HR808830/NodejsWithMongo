module.exports = {
    userSchema: require('./user')
}