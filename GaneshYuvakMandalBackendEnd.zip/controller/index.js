module.exports = {
    userCtrl:require('./user'),
    eventCtrl:require('./event'),
    complaintCtrl:require('./complaint'),
    galleryCtrl:require('./gallery'),
    balanceCtrl:require('./balance'),
    donateCtrl:require('./donate')
}