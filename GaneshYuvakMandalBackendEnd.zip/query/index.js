module.exports = {
	userQuery: require('./user'),
	eventQuery: require('./event'),
	query:require('./query')
}