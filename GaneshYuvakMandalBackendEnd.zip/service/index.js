module.exports = {
    commonService: require('./commonServices'),
    fileUpload: require('./fileUpload')
}